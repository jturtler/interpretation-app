import Store from 'd2-ui/lib/store/Store';

export default Store.create();
